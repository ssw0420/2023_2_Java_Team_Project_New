

package swing;

import java.awt.EventQueue;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;



public class EngStudy extends JFrame{

	private JFrame frame;
	private JTextField WordEngTextField1;
	private JTextField WordKorTextField1;
	private JTextField WordPronunciation1;
	private JTextField DifficultyTextField1;
	private JTextField usernameTextField;
	private JTextField userlevelTextField;
	private JTextField userhighscoreTextField;
	private JTextField WordEngTextField2;
	private JTextField WordKorTextField2;
	private JTextField WordPronunciation2;
	private JTextField DifficultyTextField2;

	public EngStudy() {
		getContentPane().setFont(new Font("굴림", Font.BOLD, 20));
		getContentPane().setBackground(SystemColor.activeCaption);
		WordMemorizeUI();
	}
	UserInfo loadedUserInfo = UserInfo.loadFromFile("src\\swing\\userlist.txt");
	ArrayList<String> names = loadedUserInfo.getNames();
	ArrayList<String> levels = loadedUserInfo.getLevels();
	ArrayList<String> highscores = loadedUserInfo.getHighscores();
	//ArrayList<String> progressNums = loadedUserInfo.getProgressNums();

	EngWord loadedEngWord = EngWord.loadFromFile("src\\swing\\wordlist.txt");
	ArrayList<String> words = loadedEngWord.getWords();
	ArrayList<String> meanings = loadedEngWord.getMeanings();
	ArrayList<String> pronunciations = loadedEngWord.getPronunciations();
   // ArrayList<String> wordslevels = loadedEngWord.getWordlevels();   
	
	
	
	int user_id = 0;
	int i =0;
	private JTextField ProgressNum1;
	private JTextField ProgressNum2;
	private void updateTextFields() {
		
	    WordEngTextField1.setText(words.get(i));
	    WordKorTextField1.setText(meanings.get(i));
	    WordPronunciation1.setText(pronunciations.get(i));
	    
	  
	    ProgressNum1.setText(Integer.toString(i+1));
	    ProgressNum2.setText(Integer.toString(i+2));
	    
	    WordEngTextField2.setText(words.get(i + 1));
	    WordKorTextField2.setText(meanings.get(i + 1));
	    WordPronunciation2.setText(pronunciations.get(i + 1));

	    
	}

	private void WordMemorizeUI() {
		setTitle("영단어 학습 프로그램");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
	
		JButton ExitButton = new JButton("나가기");
		ExitButton.setBounds(12, 10, 91, 23);
		getContentPane().add(ExitButton);
		
		JButton nextButton = new JButton(">>>");
		nextButton.setFont(new Font("굴림", Font.BOLD, 20));
		nextButton.setBounds(774, 296, 120, 53);
		getContentPane().add(nextButton);
        nextButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		if (i < words.size() - 2) {
        			i++; // i를 증가시킴
        			updateTextFields(); // 텍스트 필드 업데이트
        		}
        	}
        });
        
        JButton prevButton = new JButton("<<<");
        prevButton.setFont(new Font("굴림", Font.BOLD, 20));
        prevButton.setBounds(125, 296, 120, 53);
        getContentPane().add(prevButton);
        prevButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	
                if (i > 0) {
                    i--; // i를 감소시킴
                    updateTextFields(); // 텍스트 필드 업데이트
                }
            }
        });
        
        
        WordEngTextField1 = new JTextField();
        WordEngTextField1.setForeground(new Color(0, 0, 0));
        WordEngTextField1.setEditable(false);
        WordEngTextField1.setFont(new Font("굴림", Font.PLAIN, 20));
        WordEngTextField1.setText(words.get(i));
        WordEngTextField1.setBounds(275, 226, 160, 60);
        getContentPane().add(WordEngTextField1);
        WordEngTextField1.setColumns(10);
        
        
        
        WordKorTextField1 = new JTextField();
        WordKorTextField1.setEditable(false);
        WordKorTextField1.setFont(new Font("굴림", Font.PLAIN, 20));
        WordKorTextField1.setText(meanings.get(i));
        WordKorTextField1.setBounds(275, 295, 156, 60);
        getContentPane().add(WordKorTextField1);
        WordKorTextField1.setColumns(10);
        
        
        
        WordPronunciation1 = new JTextField();
        WordPronunciation1.setEditable(false);
        WordPronunciation1.setFont(new Font("굴림", Font.PLAIN, 20));
        WordPronunciation1.setText(pronunciations.get(i));
        WordPronunciation1.setBounds(275, 365, 156, 60);
        getContentPane().add(WordPronunciation1);
        WordPronunciation1.setColumns(10);
        
        
        
        DifficultyTextField1 = new JTextField();
        DifficultyTextField1.setEditable(false);
        DifficultyTextField1.setFont(new Font("굴림", Font.PLAIN, 20));
        DifficultyTextField1.setText(/*wordslevels.get(i)*/"초급");
        DifficultyTextField1.setBounds(275, 435, 156, 60);
        getContentPane().add(DifficultyTextField1);
        DifficultyTextField1.setColumns(10);
        
        
        usernameTextField = new JTextField();
        usernameTextField.setEditable(false);
        usernameTextField.setBackground(new Color(192, 192, 192));
        usernameTextField.setFont(new Font("굴림", Font.BOLD, 20));
        usernameTextField.setText(names.get(user_id));
        usernameTextField.setBounds(173, 70, 143, 47);
        getContentPane().add(usernameTextField);
        usernameTextField.setColumns(10);
        
        
        
        userlevelTextField = new JTextField();
        userlevelTextField.setEditable(false);
        userlevelTextField.setBackground(new Color(192, 192, 192));
        userlevelTextField.setFont(new Font("굴림", Font.BOLD, 20));
        userlevelTextField.setText(levels.get(user_id));
        userlevelTextField.setBounds(419, 70, 120, 47);
        getContentPane().add(userlevelTextField);
        userlevelTextField.setColumns(10);
        
        
        userhighscoreTextField = new JTextField();
        userhighscoreTextField.setEditable(false);
        userhighscoreTextField.setBackground(new Color(192, 192, 192));
        userhighscoreTextField.setFont(new Font("굴림", Font.BOLD, 20));
        userhighscoreTextField.setText(highscores.get(user_id));
        userhighscoreTextField.setBounds(685, 70, 120, 47);
        getContentPane().add(userhighscoreTextField);
        userhighscoreTextField.setColumns(10);
        
        WordEngTextField2 = new JTextField();
        WordEngTextField2.setEditable(false);
        WordEngTextField2.setFont(new Font("굴림", Font.PLAIN, 20));
        WordEngTextField2.setText(words.get(i+1));
        WordEngTextField2.setBounds(565, 226, 160, 60);
        getContentPane().add(WordEngTextField2);
        WordEngTextField2.setColumns(10);
        
        WordKorTextField2 = new JTextField();
        WordKorTextField2.setEditable(false);
        WordKorTextField2.setFont(new Font("굴림", Font.PLAIN, 20));
        WordKorTextField2.setText(meanings.get(i+1));
        WordKorTextField2.setBounds(565, 296, 160, 59);
        getContentPane().add(WordKorTextField2);
        WordKorTextField2.setColumns(10);
        
        WordPronunciation2 = new JTextField();
        WordPronunciation2.setEditable(false);
        WordPronunciation2.setFont(new Font("굴림", Font.PLAIN, 20));
        WordPronunciation2.setText(pronunciations.get(i+1));
        WordPronunciation2.setBounds(565, 365, 160, 60);
        getContentPane().add(WordPronunciation2);
        WordPronunciation2.setColumns(10);
        
        DifficultyTextField2 = new JTextField();
        DifficultyTextField2.setEditable(false);
        DifficultyTextField2.setFont(new Font("굴림", Font.PLAIN, 20));
        DifficultyTextField2.setText(/*wordslevels.get(i+1)*/"초급");
        DifficultyTextField2.setBounds(565, 435, 160, 60);
        getContentPane().add(DifficultyTextField2);
        DifficultyTextField2.setColumns(10);
        
        ProgressNum1 = new JTextField();
        ProgressNum1.setEditable(false);
        ProgressNum1.setText("1");
        ProgressNum1.setBounds(311, 185, 96, 21);
        getContentPane().add(ProgressNum1);
        ProgressNum1.setColumns(10);
      
        ProgressNum2 = new JTextField();
        ProgressNum2.setEditable(false);
        ProgressNum2.setText("2");
        ProgressNum2.setBounds(587, 185, 96, 21);
        getContentPane().add(ProgressNum2);
        ProgressNum2.setColumns(10);
        
        
        JToggleButton SaveProgress = new JToggleButton("책갈피");
        SaveProgress.setEnabled(true);
        SaveProgress.setBounds(872, 10, 72, 64);
        getContentPane().add(SaveProgress);
        
        JLabel UserLabel = new JLabel("사용자:");
        UserLabel.setFont(new Font("굴림", Font.BOLD, 20));
        UserLabel.setBounds(101, 70, 106, 47);
        getContentPane().add(UserLabel);
        
        JLabel levelLabel = new JLabel("단계:");
        levelLabel.setFont(new Font("굴림", Font.BOLD, 20));
        levelLabel.setBounds(370, 70, 129, 47);
        getContentPane().add(levelLabel);
        
        JLabel highscoreLabel = new JLabel("최고점수:");
        highscoreLabel.setFont(new Font("굴림", Font.BOLD, 20));
        highscoreLabel.setBounds(587, 70, 116, 47);
        getContentPane().add(highscoreLabel);
        
        JLabel lblNewLabel = new JLabel("|");
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel.setFont(new Font("굴림", Font.BOLD, 40));
        lblNewLabel.setBounds(318, 71, 50, 48);
        getContentPane().add(lblNewLabel);
        
        JLabel lblNewLabel_1 = new JLabel("|");
        lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_1.setFont(new Font("굴림", Font.BOLD, 40));
        lblNewLabel_1.setBounds(538, 72, 50, 45);
        getContentPane().add(lblNewLabel_1);
        
        JPanel panel = new JPanel();
        panel.setBackground(new Color(192, 192, 192));
        panel.setBounds(93, 70, 733, 47);
        getContentPane().add(panel);
        
        JPanel panel_1 = new JPanel();
        panel_1.setBounds(84, 62, 750, 64);
        getContentPane().add(panel_1);
        
        JPanel panel_2 = new JPanel();
        panel_2.setBounds(76, 148, 868, 394);
        getContentPane().add(panel_2);
        
        
        SaveProgress.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		UserInfo userInfo = new UserInfo();
        		// 토글 상태 확인
                boolean isToggled = SaveProgress.isSelected();

                // progressNums 값 갱신
                if (isToggled) {
                	userInfo.updateUserInfo(names.get(user_id), levels.get(user_id), highscores.get(user_id), Integer.toString(i+1));
                	userInfo.saveToFile("src\\swing\\userlist.txt");
                	
                    SaveProgress.setEnabled(true); // 한 번 토글되면 비활성화
                } else {
                    SaveProgress.setEnabled(true); // 다시 토글 가능하게 활성화
                }
                
        		
        	}
        });
		
		setResizable(false);/// 크기 고정
		setSize(1050, 600);
		setVisible(true);
	}
	
	
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new EngStudy();
        });
    }
}
